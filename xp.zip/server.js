import express from 'express';
import cors from "cors";
import pool from "./src/Server/config_db.js";
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import session from 'express-session';  // Import express-session
import courseapiRoutes from "./src/Server/courseapi.js";
import courseDisplayRoutes from "./src/Server/coursedisplayapi.js";
import subCategoryRouter from "./src/Server/subcategory_routes.js";
import bitesRouter from "./src/Server/bites_routes.js";
import sponsorRouter from "./src/Server/sponsor_routes.js";
import fetchSubcategorierouter from "./src/Server/subcategory_filter_routes.js";
import missionsSearchRouter from "./src/Server/manage_missions/mission_search.js"
import missionsRouter from "./src/Server/manage_missions/missionsRouter.js";
import chainRouter from "./src/Server/chains_routes.js";
import criteriaRouter from "./src/Server/criteria_router.js";
import userapiRoutes from "./src/Server/database_sync_routes/users_api.js";
import missionDisplayRoutes from "./src/Server/manage_missions/missions_display_api.js"
import UserBytesRouter from "./src/Server/user_bites_routes.js"
import UserMissionsRouter from "./src/Server/user_mission_routes.js";
import UserCompletedMissionsRouter from "./src/Server/user_completed_missions.js";
import UserBytesCardsRouter from "./src/Server/user_bytes_cards.js";
import WebhookByteStatusRouter from "./src/Server/user_bytes_stats_update.js";
import WebhookMissionStatusRouter from "./src/Server/user_missions_stats_update.js";
import leaderboardRouter from './src/Server/leaderboard.js';
import userProfileRouter from './src/Server/user_profile.js';
import Registerrouter from "./src/Server/registar_router.js";
import sessionRouter from "./src/Server/session_router.js";
import allmissionprogressrouter from './src/Server/database_sync_routes/all_missions_progress_endpoint.js'
import alluserprogressrouter from './src/Server/database_sync_routes/all_Bytes_progress_endpoint.js'
import MissionUnlockRouter from './src/Server/user_mission_unlock_router.js';
import Sales_page_router from './src/Server/sales_page_routes.js';
import ProgressRouter from './src/Server/zenler_progress_updates/progressRouter.js';
import sitemapRouter from './src/Server/sitemap_routes.js'
import bitesReportRouter from './src/Server/admin_dash_bytes_reports_router.js'
import missionsReportRouter from  './src/Server/admin_dash_missions_report_router.js'





// Load environment variables
dotenv.config();
const port = process.env.PORT || 80; // Dynamic port for local or production
const apiBaseUrl = process.env.API_BASE_URL || 'http://localhost:3001';
console.log(apiBaseUrl); // Available only in backend
const appUrl = process.env.APP_URL || 'http://localhost:5173';

console.log(`Backend running in ${process.env.NODE_ENV} mode`);
console.log(`API Base URL: ${apiBaseUrl}`);
console.log(`App URL: ${appUrl}`);

// Initialize the express app
const app = express();

// Resolve __dirname and __filename for use with static files
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Middleware to parse JSON bodies
app.use(express.json()); // Only use express.json()

// Configure CORS
const allowedOrigins = [
  'https://ablockofcrypto.com', 
  'http://localhost:5173',     
  'http://localhost:3000',
  'http://abc-env.eba-kytn56dh.us-east-1.elasticbeanstalk.com', 
  'xpmodule.c188ccsye2s8.us-east-1.rds.amazonaws.com',
  'http://localhost:8081',
  'https://app.ablockofcrypto.com'
];

app.use(cors({
  origin: (origin, callback) => {
    // console.log('Incoming Origin:', origin);
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      console.error(`Blocked by CORS: ${origin}`);
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true
}));





// Initialize session store using Knex
import { ConnectSessionKnexStore } from "connect-session-knex";
import knexConstructor from "knex";

const store = new ConnectSessionKnexStore({
  knex: knexConstructor({
    client: 'mysql2',
    connection: {
      host: process.env.DATABASE_HOST,
      user: process.env.DATABASE_USER,
      password: process.env.DATABASE_PASSWORD,
      database: process.env.DATABASE_NAME,
    }
  })
});

// Configure session middleware
app.use(session({
  store,
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false, // set to false for dev and true for production
    httpOnly: true,
    maxAge: 1000 * 60 * 60 * 24,
    sameSite: 'lax'
  }
}));

// middleware to enforce HTTPS
if (process.env.NODE_ENV === 'production') {
  app.use((req, res, next) => {
    if (req.headers['x-forwarded-proto'] !== 'https') {
      return res.redirect(`https://${req.headers.host}${req.url}`);
    }
    next();
  });
} else {
  console.log('HTTPS enforcement disabled in development mode.');
}

// Serve static files in production mode
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, 'public'), {
    setHeaders: (res, path) => {
      if (path.endsWith('.js')) {
        res.setHeader('Content-Type', 'application/javascript');
      }
    }
  }));
}


// Use API routes
app.use('/api', courseapiRoutes); // this route is for getting the bites/missions data from zenler
app.use('/api', userapiRoutes); // this route is for getting the user data from zenler
app.use('/api', courseDisplayRoutes); // this route is for the bitescards
app.use('/api', subCategoryRouter); // this route is for subcategory CRUD operations
app.use('/api', bitesRouter); // this route is for bites CRUD operations
app.use('/api', sponsorRouter); // this route is for sponsor/partner CRUD operations
app.use('/api/fetchsubcategories', fetchSubcategorierouter); // this route is for fetching subcategories for the filters on bites and missions
app.use('/api/missions', missionsSearchRouter);
app.use('/api', missionsRouter); // this route is for mission CRUD operations
app.use ('/api', chainRouter); // this route is for chains CRUD operations
app.use ('/api',criteriaRouter); // this route is for criteria CRUD operations
app.use ('/api',missionDisplayRoutes); // this route is for the missioncards
app.use ('/api', UserBytesRouter); // this route is for the user/bites data
app.use ('/api', UserMissionsRouter); // this route is for the user/missions data
app.use ('/api',UserCompletedMissionsRouter);// this route is for the user completed missions data
app.use ('/api', UserBytesCardsRouter);
app.use('/api', WebhookByteStatusRouter); //this route is for updating the user bytes status when a byte is started or complete
app.use('/api', WebhookMissionStatusRouter); //this route is for updating the user mission status when a mission is started or complete
app.use('/api', leaderboardRouter); //this route calcaultes the leaderboard

app.use('/api',Registerrouter); // this route is used for the sign in/sign up/reset password options
app.use('/api', allmissionprogressrouter); //this route syncs the DB with zenler for user progress on missions
app.use('/api', alluserprogressrouter); //this route syncs the DB with zenler for user progress on bytes
app.use('/api', MissionUnlockRouter); //this route calcualtes unlocked missions for a user
app.use('/api', Sales_page_router) //this route is for updating the sales pages CRUD operations
app.use('/session', sessionRouter); // All session-related routes will be prefixed with /session
app.use('/api', ProgressRouter);
app.use('/api', sitemapRouter);
app.use('/api', bitesReportRouter);
app.use('/api', missionsReportRouter);
app.use('/api', userProfileRouter);

app.get('/health', (req, res) => res.status(200).send('OK'));

// Test database connection endpoint
app.get('/test-db', (req, res) => {
  console.log('Attempting database query...');
  pool.query('SELECT 1', (err, results) => {
    if (err) {
      console.error('Database query error:', err);
      res.status(500).send('Database query failed');
      return;
    }
    console.log('Database query successful:', results);
    res.send('Database connection is working!');
  });
});

// Catch-all route to serve the React app for unknown routes (for SPA functionality)
// This route should come last to avoid interfering with API routes
// Serve index.html only for requests without a file extension
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
// Start the server
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});