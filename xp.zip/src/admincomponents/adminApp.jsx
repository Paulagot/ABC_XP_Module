
import React from "react"
import AdminDashboard from './admindash'


function Admin_App() {
    return(    
       
        <AdminDashboard />       
      
    )
}
export default Admin_App