import React from 'react';

const Header = () => {
  return <header>insert header</header>;
};

export default Header;