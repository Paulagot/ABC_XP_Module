import React, { useState, useEffect } from 'react';
import UserStatsCard from './userStatCards';
import  CategoryList  from './CategoryList';
import CategoryDetailModal from './CategoryDetailModal';
import axios from 'axios';


const CategoryNFTDashboard = () => {
  // Dummy data (to be replaced with backend data)
  const [userStats, setUserStats] = useState({
    learningStreak: 12,
    leaderboardRank: 42,
    achievements: [
      { 
        name: "Learning Streak", 
        icon: "🔥", 
        levels: [
          { threshold: 7, name: "Spark", achieved: true },
          { threshold: 30, name: "Flame", achieved: false },
          { threshold: 90, name: "Inferno", achieved: false }
        ]
      },
      { 
        name: "Category Explorer", 
        icon: "🗺️", 
        levels: [
          { threshold: 1, name: "Novice", achieved: true },
          { threshold: 3, name: "Pathfinder", achieved: false },
          { threshold: 5, name: "Master Explorer", achieved: false }
        ]
      },
      { 
        name: "Mission Completer", 
        icon: "🎯", 
        levels: [
          { threshold: 10, name: "Rookie", achieved: true },
          { threshold: 50, name: "Veteran", achieved: false },
          { threshold: 100, name: "Legend", achieved: false }
        ]
      }
    ],
    categories: [
      { 
        name: "Decentralized Finance", 
        progress: 0.65, 
        color: "bg-blue-500",
        levels: [
          { name: "Essentials", progress: 0.4, missions: { total: 5, unlocked: 3, completed: 2 } },
          { name: "Beginners", progress: 0.6, missions: { total: 7, unlocked: 5, completed: 3 } },
          { name: "Intermediate", progress: 0.3, missions: { total: 10, unlocked: 4, completed: 1 } },
          { name: "Advanced", progress: 0.1, missions: { total: 8, unlocked: 1, completed: 0 } }
        ]
      },
   
    ]
  });

  const [selectedCategory, setSelectedCategory] = useState(null);

  // NFT Preview template (can be moved to a config file)
  const nftPreviewTemplate = {
    backgroundColor: "bg-gradient-to-br from-blue-100 to-purple-100",
    borderStyle: "border-4 border-blue-300",
    overlayDetails: [
      { label: "Category", value: "Programming" },
      { label: "Levels Completed", value: "3/4" },
      { label: "Total Progress", value: "85%" },
      { label: "Missions Completed", value: "42/50" }
    ]
  };

  const toggleCategory = (categoryName) => {
    setSelectedCategory(
      selectedCategory === categoryName ? null : categoryName
    );
  };

  // Find selected category details
  const selectedCategoryDetails = selectedCategory 
    ? userStats.categories.find(cat => cat.name === selectedCategory)
    : null;

  return (
    <div className="nft-dashboard-container">
      <UserStatsCard userStats={userStats} />
      
      <CategoryList 
        categories={userStats.categories} 
        onCategorySelect={toggleCategory} 
      />
      
      {selectedCategoryDetails && (
        <CategoryDetailModal 
          category={selectedCategoryDetails}
          nftPreviewTemplate={nftPreviewTemplate}
        />
      )}
    </div>
  );
};

export default CategoryNFTDashboard;