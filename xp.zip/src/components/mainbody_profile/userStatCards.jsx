// src/components/UserStatsCard.jsx
import React from 'react';
import AchievementsCard from './AchievementCards';


const UserStatsCard = ({ userStats }) => {
  return (
    <div className="user-stats-grid">
      <div className="user-rank-card">
        <h2 className="card-title">Your Rank</h2>
        <div className="rank-content">
          <div className="rank-number">#{userStats.leaderboardRank}</div>
          <div className="rank-description">Global Leaderboard</div>
        </div>
      </div>

      <div className="learning-streak-card">
        <h2 className="card-title">Learning Streak</h2>
        <div className="streak-content">
          <div className="streak-number">{userStats.learningStreak}</div>
          <div className="streak-description">Consecutive Days</div>
        </div>
      </div>

      <AchievementsCard achievements={userStats.achievements} />
    </div>
  );
};

export default UserStatsCard;