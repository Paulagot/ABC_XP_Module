import React from 'react';


const NFTPreviewCard = ({ nftPreviewTemplate, categoryName }) => {
  return (
    <div 
      className={`nft-preview-card ${nftPreviewTemplate.backgroundColor} ${nftPreviewTemplate.borderStyle}`}
    >
      <div className="nft-preview-actions">
        <button className="nft-action-button">
          {categoryName === "Blockchain" ? "View on Chain" : "Mint NFT"}
        </button>
      </div>
      <h3 className="nft-preview-title">NFT Certificate Preview</h3>
      <div className="nft-preview-details">
        {nftPreviewTemplate.overlayDetails.map((detail, idx) => (
          <div key={idx} className="nft-detail-row">
            <span className="nft-detail-label">{detail.label}:</span>
            <span className="nft-detail-value">{detail.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default NFTPreviewCard;