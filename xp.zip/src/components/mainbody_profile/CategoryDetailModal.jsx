// src/components/CategoryDetailModal.jsx
import React from 'react';
import CategoryProgressDetails from './CategoryProgressDetails';
import NFTPreviewCard from './NFTPreviewCard';



const CategoryDetailModal = ({ category, nftPreviewTemplate }) => {
  return (
    <div className="category-detail-grid">
      <CategoryProgressDetails category={category} />
      <NFTPreviewCard 
        nftPreviewTemplate={nftPreviewTemplate} 
        categoryName={category.name} 
      />
    </div>
  );
};

export default CategoryDetailModal;