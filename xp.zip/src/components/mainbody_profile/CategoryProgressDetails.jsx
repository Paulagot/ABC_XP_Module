import React from 'react';
import ProgressBar from './ProgressBar';

const CategoryProgressDetails = ({ category }) => {
  return (
    <div className="category-progress-details">
      <h2 className="category-details-title">{category.name} Details</h2>
      <div className="progress-list">
        {category.levels.map((level, idx) => (
          <ProgressBar 
            key={idx} 
            level={level.name} 
            progress={level.progress * 100} 
          />
        ))}
      </div>
    </div>
  );
};

export default CategoryProgressDetails;