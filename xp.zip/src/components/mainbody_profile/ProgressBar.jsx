import React from 'react';


const ProgressBar = ({ level, progress }) => {
  return (
    <div className="progress-bar-container">
      <div className="progress-bar-header">
        <span className="progress-level">{level}</span>
        <span className="progress-percentage">{progress.toFixed(0)}%</span>
      </div>
      <div className="progress-track">
        <div 
          className="progress-fill" 
          style={{width: `${progress}%`}}
        ></div>
      </div>
    </div>
  );
};

export default ProgressBar;