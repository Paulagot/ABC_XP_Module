//bytes main body

import  WidgetPage  from "./Lifi_widget";



function Learnfi_main_body() {
   
    return (
        <main className="container__right" id="main">
           
            <WidgetPage />
        </main>    
        
    );
}

export default Learnfi_main_body;