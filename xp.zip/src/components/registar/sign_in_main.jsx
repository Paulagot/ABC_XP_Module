// sign_in_main_body.js
import React, { useState, useEffect } from 'react';
import SignUpForm from './sing_up_form';
import SignInForm from './sign_in_form';
import ResetPasswordForm from './reset_password';
import SetPasswordForm from './set_password';
import { useLocation } from 'react-router-dom';

/**
 * Main container component for handling sign-in, sign-up, reset password, and set password views.
 * Dynamically renders the appropriate form based on the 'view' state and URL parameters.
 */
function SignInMainBody() {
    const [view, setView] = useState('signIn');
    const [resetToken, setResetToken] = useState(null);
    const location = useLocation();

    useEffect(() => {
        const params = new URLSearchParams(location.search);
        const urlView = params.get('view');
        const urlToken = params.get('token');

        if (urlView) setView(urlView);
        if (urlView === 'setPassword' && urlToken) setResetToken(urlToken);
    }, [location]);

    const handleSignUp = () => {
        setView('signIn');
    };

    const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;
    const APP_URL = import.meta.env.VITE_APP_URL;

    const handleSignIn = async (formData) => {
        try {
            const response = await fetch(`${API_BASE_URL}/api/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData),
            });
            if (response.ok) {
                window.location.href = `${APP_URL}/bytes`;
            } else {
                const data = await response.json();
                console.error(data.error);
            }
        } catch (error) {
            console.error('Sign-in error:', error);
        }
    };

    // Define handlePasswordReset and pass it to ResetPasswordForm
    const handlePasswordReset = async (email, captchaToken) => {
        try {
            const response = await fetch(`${API_BASE_URL}/api/password-reset`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, captchaToken }),
            });
            return response.ok;
        } catch (error) {
            console.error('Password reset error:', error);
            return false;
        }
    };

    return (
        <main className="container__right" id="main">
            {view === 'signIn' && <SignInForm onSignIn={handleSignIn} />}
            {view === 'signUp' && <SignUpForm onSignUp={handleSignUp} />}
            {view === 'resetPassword' && <ResetPasswordForm onReset={handlePasswordReset} />}
            {view === 'setPassword' && <SetPasswordForm token={resetToken} />}

            <div className="toggle-links">
                {view !== 'signIn' && (
                    <button onClick={() => setView('signIn')}>Sign In</button>
                )}
                {view !== 'signUp' && (
                    <button onClick={() => setView('signUp')}>Sign Up</button>
                )}
                {view !== 'resetPassword' && (
                    <button onClick={() => setView('resetPassword')}>Forgot Password?</button>
                )}
            </div>
        </main>
    );
}

export default SignInMainBody;
