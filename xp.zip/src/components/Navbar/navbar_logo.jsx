import React from "react";


function Navbar_logo (){
    return(     
        <div className="navbar__logo_container">
            <a href="https://www.ablockofcrypto.com/">
            <img className="nav-logo_image" src="/white_green logo.png" alt="abc logo" />
            </a>
        </div>                                 
        )
}

export default Navbar_logo