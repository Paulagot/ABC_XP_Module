import React from "react";


function Meetup (){
    return(     
       
            <a className="link_admin"  href="https://www.ablockofcrypto.com/calendar">
            <div className = "blog_title">EVENT'S & SOCIAL MEETUP'S </div>
            <div className = "blog_title"> Calendar of Events </div>
            <img alt ="meetupimg" src="https://secure.meetupstatic.com/photos/event/d/c/2/5/600_498356357.webp?w=384" className="admin-image"/>
            
            </a>
                                          
        )
}

export default Meetup