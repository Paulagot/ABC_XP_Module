import React from "react";
import Page_header from "../Navbar/pageheader";

function Loyalty_main_body() {  

    return (
        <main className="container__right" id="main">
           
                  
            {/* Render something */}
            
            {/* Render what ever we are showing */}
            
        </main>
    );
}

export default Loyalty_main_body;