// userProfile.js

import express from 'express';
import pool from './config_db.js';

const userProfileRouter = express.Router();

// Route to fetch user profile data and categories
userProfileRouter.get('/profile', async (req, res) => {
  try {
    const userId = req.query.userId; // Get userId from query parameter
    if (!userId) {
      return res.status(400).json({ error: 'User ID is required' });
    }

    // SQL query to fetch categories with user progress
    const categoriesQuery = `
      SELECT 
        c.category_id,
        c.name AS category_name,
        COALESCE(
          (SELECT COUNT(DISTINCT ubs.subcategory_id) 
           FROM user_bytes_stats ubs 
           JOIN bites b ON ubs.bite_id = b.bite_id 
           WHERE ubs.user_id = ? AND b.category_id = c.category_id),
          0
        ) AS completed_subcategories,
        COALESCE(
          (SELECT COUNT(DISTINCT b.subcategory_id) 
           FROM bites b 
           WHERE b.category_id = c.category_id),
          0
        ) AS total_subcategories,
        CASE 
          WHEN total_subcategories > 0 
          THEN ROUND(completed_subcategories * 100.0 / total_subcategories, 2) 
          ELSE 0 
        END AS progress
      FROM 
        categories c
      ORDER BY 
        c.name
    `;

    const [categories] = await pool.query(categoriesQuery, [userId]);

    // Prepare categories with color and progress
    const formattedCategories = categories.map((cat, index) => ({
      name: cat.category_name,
      progress: cat.progress / 100, // Convert to 0-1 range
      color: getProgressColor(index), // Function to assign colors
      levels: [] // You can add level details if needed
    }));

    res.json({ categories: formattedCategories });
  } catch (error) {
    console.error('Error fetching profile data:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Helper function to assign colors to categories
function getProgressColor(index) {
  const colors = [
    'bg-blue-500', 
    'bg-green-500', 
    'bg-purple-500', 
    'bg-red-500', 
    'bg-yellow-500'
  ];
  return colors[index % colors.length];
}

export default userProfileRouter;